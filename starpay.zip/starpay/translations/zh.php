<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{wechatpay}prestashop>wechatpay_d1ae6863be68f1b64a61b51c836a2e6f'] = '更新成功';
$_MODULE['<{wechatpay}prestashop>wechatpay_b6245e3bf6a0c6541cc3b2533244ad27'] = '微信支付';
$_MODULE['<{wechatpay}prestashop>wechatpay_5f40cc7cf1f9cc26a8799140ec389d8b'] = '访问ID';
$_MODULE['<{wechatpay}prestashop>wechatpay_cbe14a117996d7330bf64d0d03c73de2'] = '由Starpay提供的访问ID';
$_MODULE['<{wechatpay}prestashop>wechatpay_6951b20a07dddec33ff59409cd651d85'] = 'A123121213';
$_MODULE['<{wechatpay}prestashop>wechatpay_c75093d143073182935b5313d6188e18'] = '商户接入号';
$_MODULE['<{wechatpay}prestashop>wechatpay_bbcd31a9899f38ccc666a7b88f00ff6f'] = 'Starpay提供的商家接入号码';
$_MODULE['<{wechatpay}prestashop>wechatpay_59c3179e9405690ff871afd09ec8ca3b'] = 'B553121213';
$_MODULE['<{wechatpay}prestashop>wechatpay_1a960e45927541718a3da96c18d774cb'] = '商店编号';
$_MODULE['<{wechatpay}prestashop>wechatpay_c6f057b86584942e415435ffb1fa93d4'] = '000';
$_MODULE['<{wechatpay}prestashop>wechatpay_d2560860c51f895a9871741f0805c39e'] = '私钥';
$_MODULE['<{wechatpay}prestashop>wechatpay_b97c5d06bc8e94bcc88e7da05523f288'] = '-----BEGIN RSA PRIVATE KEY-----';
$_MODULE['<{wechatpay}prestashop>wechatpay_c9cc8cce247e49bae79f15173ce97354'] = '拯救';
$_MODULE['<{wechatpay}prestashop>payment_execution_f1d3b424cd68795ecaa552883759aceb'] = '订单摘要';
$_MODULE['<{wechatpay}prestashop>payment_execution_879f6b8877752685a966564d072f498f'] = '你的购物车是空的';
$_MODULE['<{wechatpay}prestashop>payment_execution_a77c74850dede0a1eaa6291cc2bc7979'] = '微信支付';
$_MODULE['<{wechatpay}prestashop>payment_execution_3b3b41f131194e747489ef93e778ed0d'] = '您的订单总金额达到了';
$_MODULE['<{wechatpay}prestashop>payment_execution_1f87346a16cf80c372065de3c54c86d9'] = '税款包括';
$_MODULE['<{wechatpay}prestashop>payment_execution_afd2ef7177cb5ef2b0f287fbbb0c5c78'] = '我们接受几种货币来接收微信付款';
$_MODULE['<{wechatpay}prestashop>payment_execution_a7a08622ee5c8019b57354b99b7693b2'] = '选择以下一项';
$_MODULE['<{wechatpay}prestashop>payment_execution_57e3507ed29412a241b83b883a163bdd'] = '我们允许用微信发送以下货币';
$_MODULE['<{wechatpay}prestashop>payment_execution_c2c84101a17c8a6cad74f4770371e432'] = '发生了一些事情，检查微信支付的模块设置';
$_MODULE['<{wechatpay}prestashop>payment_execution_444d4d1d26f8595be7d86bbf07787f8f'] = '用我的支付模块支付';
